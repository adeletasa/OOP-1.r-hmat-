import javax.swing.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.Dimension;

public class Peaklass {
    public static void main(String[] args) {

        // nupud
        Object[] n1 = {"Hakkame pihta"};
        Object[] n2 = {"Mängi uuesti", "Kinni"};

        // Tervitus
        JOptionPane.showOptionDialog(null, "Tere! See on börsimäng.\nAndmed tulevad failist.",
                "Mäng", 0, 1, null, n1, n1[0]);

        boolean kestab = true;

        while (kestab) {
            ArrayList<Aktsia> list = laeAktsiad("src/aktsiad.txt");

            if (list.isEmpty()) break;

            String nimi = küsiTeksti("Nimi:", "Andmed");
            if (nimi == null) break;

            double raha = küsiNumbrit("Palju raha on?", "Kapital");
            if (raha == -1) break;

            Portfell p = new Portfell(nimi, raha);
            Turu t = new Turu();

            Aktsia a = valiAktsia(list);
            if (a == null) break;

            int kogus = (int) küsiNumbrit("Hind: " + a.getHind() + "\nSinu raha: " + p.getVabaRaha() + "\n\nMitu ostad?", "Ost");

            if (kogus > 0) {
                if (p.osta(kogus, a.getHind()) == false) {
                    JOptionPane.showMessageDialog(null, "Raha pole piisavalt!");
                }
            }

            Object[] ajad = {"5 päeva", "30 päeva"};
            int valik = JOptionPane.showOptionDialog(null, "Vali aeg:", "Aeg", 0, 3, null, ajad, ajad[0]);
            if (valik == -1) break;

            int päevi = 5;
            if (valik == 1) päevi = 30;

            double algus = p.arvutaVäärtus(a.getHind());
            String tekst = "";

            for (int i = 1; i <= päevi; i++) {
                a.uuendaHinda(t.genereeriMuutus(a.getVolatiilsus()));
                if (päevi <= 5 || i % 5 == 0 || i == päevi) {
                    tekst += "Päev " + i + ": " + Math.round(a.getHind() * 100.0) / 100.0 + " EUR\n";
                }
            }

            double lõpp = p.arvutaVäärtus(a.getHind());
            double tulemus = lõpp - algus;

            String raport = "KOKKUVÕTE: " + a.getNimi() + "\n\n" + tekst +
                    "\nAlgus: " + Math.round(algus * 100.0) / 100.0 +
                    "\nLõpp: " + Math.round(lõpp * 100.0) / 100.0 +
                    "\nVahe: " + Math.round(tulemus * 100.0) / 100.0;

            int lõppvalik = JOptionPane.showOptionDialog(null, raport, "Valmis", 0, 1, null, n2, n2[0]);
            if (lõppvalik != 0) kestab = false;
        }
    }

    private static String küsiTeksti(String k, String p) {
        JTextField v = new JTextField();
        Object[] s = {k, v};
        int val = JOptionPane.showOptionDialog(null, s, p, 0, -1, null, new Object[]{"OK"}, "OK");
        if (val == 0) return v.getText();
        return null;
    }

    // küsib raha numbri
    // kui sisestatakse midagi peale numbri siis küsib uuesti kuni sisestatud info on õige
    private static double küsiNumbrit(String k, String p) {
        JTextField v = new JTextField();
        Object[] s = {k, v};
        while (true) {
            int val = JOptionPane.showOptionDialog(null, s, p, 0, -1, null, new Object[]{"OK"}, "OK");
            if (val != 0) return -1;
            try {
                return Double.parseDouble(v.getText().replace(",", "."));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Sisesta number!");
            }
        }
    }

    // saab valida aktsiat
    private static Aktsia valiAktsia(ArrayList<Aktsia> list) {
        String s = "Vali aktsia number:\n";
        for (int i = 0; i < list.size(); i++) {
            s += (i + 1) + ". " + list.get(i).getNimi() + " (" + list.get(i).getHind() + ")\n";
        }
        JTextField v = new JTextField();
        Object[] sisu = {new JScrollPane(new JTextArea(s)), "Number:", v};
        int val = JOptionPane.showOptionDialog(null, sisu, "Valik", 0, -1, null, new Object[]{"Vali"}, "Vali");
        if (val == 0) {
            try {
                return list.get(Integer.parseInt(v.getText()) - 1);
            } catch (Exception e) {
                return valiAktsia(list);
            }
        }
        return null;
    }

    // loeb "aktsiad.txt" failist
    private static ArrayList<Aktsia> laeAktsiad(String fail) {
        ArrayList<Aktsia> aktsiad = new ArrayList<>();
        try (Scanner sc = new Scanner(new File(fail))) {
            while (sc.hasNextLine()) {
                String[] jupid = sc.nextLine().split(",");
                if (jupid.length == 3) {
                    aktsiad.add(new Aktsia(jupid[0].trim(), Double.parseDouble(jupid[1].trim()), Double.parseDouble(jupid[2].trim())));
                }
            }
        } catch (Exception e) {
            System.out.println("Faili ei leitud");
        }
        return aktsiad;
    }
}