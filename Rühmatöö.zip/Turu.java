import java.util.Random;

public class Turu {
    private Random juhuslik = new Random();

    public double genereeriMuutus(double volatiilsus) {
        // See valem teeb muutuse vahemikus [-risk, +risk]
        return (juhuslik.nextDouble() * 2 * volatiilsus) - volatiilsus;
    }
}